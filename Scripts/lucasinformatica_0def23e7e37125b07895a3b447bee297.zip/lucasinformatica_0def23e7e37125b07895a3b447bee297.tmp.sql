--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 13.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AnaliseProposta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AnaliseProposta" (
    id integer NOT NULL,
    "idSituacaoProposta" integer NOT NULL,
    "dataLiberacao" timestamp without time zone,
    motivo character varying(200),
    "idDigitacao" bigint NOT NULL
);


--
-- Name: AniversarianteDia; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AniversarianteDia" (
    id bigint NOT NULL,
    "idCliente" bigint,
    "dataNascimento" timestamp without time zone,
    nome character varying(10),
    "Cpf" character varying(10)
);


--
-- Name: Banco; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Banco" (
    id integer NOT NULL,
    "dataCadastro" timestamp without time zone,
    descriicao character varying(100)
);


--
-- Name: CartelaClienteFinanceira; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CartelaClienteFinanceira" (
    id bigint NOT NULL,
    "IdCliente" bigint,
    "dataFechamento" timestamp without time zone,
    "idAnaliseProposta" integer NOT NULL
);


--
-- Name: Cliente; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Cliente" (
    "Id" bigint NOT NULL,
    "idTipoBeneficiario" integer NOT NULL,
    "idSitucaoCredito" character(10) NOT NULL,
    "nomeTestemunha" character varying(100),
    "idUsuario" bigint,
    obersevacao character varying(200),
    endereco character varying(100),
    "dataCadastro" date,
    conhecido character varying(100),
    "Cpf" character varying(11),
    "dataNascimento" date,
    "Rg" character varying(11),
    "pontoReferencia" character varying(100),
    email character varying(50),
    "Nome" character varying(100)
);


--
-- Name: ControleProducao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ControleProducao" (
    "idSituacaoControleProducao" integer NOT NULL,
    "IdAnaliseProposta" integer NOT NULL,
    id character(10),
    "valorRecebimento" numeric(10,0),
    "NomeCliente" character(10)
);


--
-- Name: Digitacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Digitacao" (
    id bigint NOT NULL,
    "idCliente" bigint,
    "dataDigitacao" timestamp without time zone,
    obervacao character varying(200),
    "idUsuario" bigint,
    "dataCadastro" timestamp without time zone,
    "flagDigitacao" boolean
);


--
-- Name: DocumentoAssinatura; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentoAssinatura" (
    id bigint NOT NULL,
    "assinaturaCliente" character varying(200),
    "assinaturaRogo" character varying(200),
    "idSimulacao" bigint NOT NULL
);


--
-- Name: DocumentoCliente; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentoCliente" (
    id bigint NOT NULL,
    "idDigitacao" bigint NOT NULL,
    "idPerfil" integer,
    "dataAutalizacao" date,
    "dataCadastro" date,
    "dataAnexo" date,
    "Documento" character varying(100) NOT NULL,
    "idCliente" bigint
);


--
-- Name: Empresa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Empresa" (
    "Id" integer NOT NULL,
    "Cep" character varying(25),
    numero integer,
    endereco character varying(100),
    "Bairro" character(10),
    "idUsuario" bigint NOT NULL,
    "nomeFantasia" character varying(10),
    "Email" character varying(10),
    celular character varying(10),
    "Cnpj" character varying(20),
    "razacaoSocial" character varying(100)
);


--
-- Name: Perfil; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Perfil" (
    id bigint NOT NULL,
    nome character(100)
);


--
-- Name: Perfil_Usuario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Perfil_Usuario" (
    id bigint NOT NULL,
    "idUsuario" bigint NOT NULL,
    "idPerfil" bigint NOT NULL
);


--
-- Name: Perfil_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."Perfil" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Perfil_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: PreAgendamento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAgendamento" (
    id integer NOT NULL,
    "idCliente" bigint NOT NULL,
    "DataAgendamento" character(10),
    "Nome" character(10),
    "Cpf" character(10)
);


--
-- Name: Produto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Produto" (
    "Id" integer NOT NULL,
    descricao character varying(100)
);


--
-- Name: Produto_Banco; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Produto_Banco" (
    id bigint NOT NULL,
    "IdProduto" integer NOT NULL,
    "idBanco" integer NOT NULL
);


--
-- Name: Simulacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Simulacao" (
    id bigint NOT NULL,
    obervacao character varying(100),
    "idCliente" bigint,
    "numeroBeneficio" bigint,
    "dataBeneficio" date,
    bloqueado boolean,
    "representanteLegal" boolean
);


--
-- Name: SimulacaoBanco; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SimulacaoBanco" (
    id bigint NOT NULL,
    "idProdutoBanco" bigint NOT NULL,
    "FlagSimulado" boolean,
    "valorOperacao" numeric(10,0),
    "QuantidadeParcela" integer,
    "ValorParcela" numeric(10,0),
    "idSimulacao" bigint NOT NULL
);


--
-- Name: SituacaoControleProducao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SituacaoControleProducao" (
    id integer NOT NULL,
    "Descricao" character varying(50)
);


--
-- Name: SituacaoCredito; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SituacaoCredito" (
    "idCliente" character(10) NOT NULL,
    "Descricao" character(10)
);


--
-- Name: SituacaoProposta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SituacaoProposta" (
    id integer NOT NULL,
    descricao character varying(100)
);


--
-- Name: TelaTransacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TelaTransacao" (
    id bigint NOT NULL,
    descricao character varying(10),
    action character varying(10),
    controller character varying(10)
);


--
-- Name: Telefone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Telefone" (
    "Id" integer NOT NULL,
    "Numero" character varying(10),
    "IdCliente" bigint NOT NULL
);


--
-- Name: TipoBeneficio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TipoBeneficio" (
    id integer NOT NULL,
    "Descricao" character varying(10)
);


--
-- Name: TransacaoPerfil; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TransacaoPerfil" (
    "idTelaTransacao" bigint NOT NULL,
    "idPerfil" bigint NOT NULL,
    id bigint NOT NULL
);


--
-- Name: id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.id_usuario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Usuario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Usuario" (
    id bigint DEFAULT nextval('public.id_usuario_seq'::regclass) NOT NULL,
    "nomeCompleto" character(100),
    "dataAtualizacao" date,
    "dataCadastro" date,
    login character(100),
    senha character(100),
    ativo boolean
);


--
-- Data for Name: AnaliseProposta; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AniversarianteDia; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Banco; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: CartelaClienteFinanceira; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Cliente; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ControleProducao; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Digitacao; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: DocumentoAssinatura; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: DocumentoCliente; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Empresa; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Perfil; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (24, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (25, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (26, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (27, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (28, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (29, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (30, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (31, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (32, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (33, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (34, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (35, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (36, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (37, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (38, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (39, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (40, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (41, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (42, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (20, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (21, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (22, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (23, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (43, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (44, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (46, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (47, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (49, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (48, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (50, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (51, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (52, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (53, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (54, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (55, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (56, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (57, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (58, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (59, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (60, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (61, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (62, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (63, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (64, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (65, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (66, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (67, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (68, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (69, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (70, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (71, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (72, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (73, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (74, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (75, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (76, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (77, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (78, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (79, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (80, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (81, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (82, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (83, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (84, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (85, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (86, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (87, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (88, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (89, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (90, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (91, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (92, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (93, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (94, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (95, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (96, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (97, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (98, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (99, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (100, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (101, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (102, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (103, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (104, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (105, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (106, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (107, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (108, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (109, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (110, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (111, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (112, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (113, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (114, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (115, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (116, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (117, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (118, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (119, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (120, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (121, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (122, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (123, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (124, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (125, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (126, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (127, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (128, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (129, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (130, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (131, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (132, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (133, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (134, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (135, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (136, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (137, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (138, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (139, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (140, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (141, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (142, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (143, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (144, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (145, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (146, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (147, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (148, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (149, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (150, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (151, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (152, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (153, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (154, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (155, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (156, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (157, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (158, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (159, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (160, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (161, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (162, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (163, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (164, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (165, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (166, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (167, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (168, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (169, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (170, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (171, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (172, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (173, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (174, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (175, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (176, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (177, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (178, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (179, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (180, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (181, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (182, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (183, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (184, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (185, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (186, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (187, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (188, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (189, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (190, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (191, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (192, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (193, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (194, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (195, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (196, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (197, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (198, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (199, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (200, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (201, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (202, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (203, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (204, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (205, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (206, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (207, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (208, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (209, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (210, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (211, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (212, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (213, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (214, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (215, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (216, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (217, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (218, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (219, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (220, 'Lucas                                                                                               ');
INSERT INTO public."Perfil" OVERRIDING SYSTEM VALUE VALUES (221, 'Lucas                                                                                               ');


--
-- Data for Name: Perfil_Usuario; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: PreAgendamento; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Produto; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Produto_Banco; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Simulacao; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: SimulacaoBanco; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: SituacaoControleProducao; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: SituacaoCredito; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: SituacaoProposta; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: TelaTransacao; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Telefone; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: TipoBeneficio; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: TransacaoPerfil; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Usuario; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."Usuario" VALUES (18, 'alana santos12212                                                                                   ', NULL, '2023-03-14', 'sARA01@45                                                                                           ', '12212                                                                                               ', true);
INSERT INTO public."Usuario" VALUES (15, 'alana santos                                                                                        ', NULL, '2023-03-13', 'sARA01@45                                                                                           ', '14567                                                                                               ', true);
INSERT INTO public."Usuario" VALUES (16, 'alana santos                                                                                        ', NULL, '2023-03-13', 'sARA01@45                                                                                           ', '14567                                                                                               ', true);
INSERT INTO public."Usuario" VALUES (17, 'alana santos                                                                                        ', NULL, '2023-03-13', 'sARA01@45                                                                                           ', '14567                                                                                               ', true);
INSERT INTO public."Usuario" VALUES (7, 'SaraIslaine                                                                                         ', NULL, '2023-03-07', 'sARA01@                                                                                             ', '8765                                                                                                ', true);
INSERT INTO public."Usuario" VALUES (8, 'Sara Islaine Santana                                                                                ', NULL, '2023-03-07', 'sARA0140@                                                                                           ', '345                                                                                                 ', true);


--
-- Name: Perfil_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Perfil_id_seq"', 221, true);


--
-- Name: id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.id_usuario_seq', 18, true);


--
-- Name: DocumentoCliente DocumentoCliente_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentoCliente"
    ADD CONSTRAINT "DocumentoCliente_pkey" PRIMARY KEY (id);


--
-- Name: TransacaoPerfil Id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TransacaoPerfil"
    ADD CONSTRAINT "Id" PRIMARY KEY (id);


--
-- Name: Cliente PK1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cliente"
    ADD CONSTRAINT "PK1" PRIMARY KEY ("Id");


--
-- Name: Empresa PK15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Empresa"
    ADD CONSTRAINT "PK15" PRIMARY KEY ("Id");


--
-- Name: Perfil_Usuario PK18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Perfil_Usuario"
    ADD CONSTRAINT "PK18" PRIMARY KEY (id);


--
-- Name: Usuario PK19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Usuario"
    ADD CONSTRAINT "PK19" PRIMARY KEY (id);


--
-- Name: Perfil PK20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Perfil"
    ADD CONSTRAINT "PK20" PRIMARY KEY (id);


--
-- Name: TelaTransacao PK21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TelaTransacao"
    ADD CONSTRAINT "PK21" PRIMARY KEY (id);


--
-- Name: Digitacao PK24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Digitacao"
    ADD CONSTRAINT "PK24" PRIMARY KEY (id);


--
-- Name: PreAgendamento PK27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAgendamento"
    ADD CONSTRAINT "PK27" PRIMARY KEY (id);


--
-- Name: CartelaClienteFinanceira PK28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CartelaClienteFinanceira"
    ADD CONSTRAINT "PK28" PRIMARY KEY (id);


--
-- Name: SituacaoCredito PK29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SituacaoCredito"
    ADD CONSTRAINT "PK29" PRIMARY KEY ("idCliente");


--
-- Name: Telefone PK3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Telefone"
    ADD CONSTRAINT "PK3" PRIMARY KEY ("Id");


--
-- Name: DocumentoAssinatura PK30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentoAssinatura"
    ADD CONSTRAINT "PK30" PRIMARY KEY (id);


--
-- Name: AniversarianteDia PK31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AniversarianteDia"
    ADD CONSTRAINT "PK31" PRIMARY KEY (id);


--
-- Name: Banco PK35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Banco"
    ADD CONSTRAINT "PK35" PRIMARY KEY (id);


--
-- Name: Produto PK37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Produto"
    ADD CONSTRAINT "PK37" PRIMARY KEY ("Id");


--
-- Name: Produto_Banco PK39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Produto_Banco"
    ADD CONSTRAINT "PK39" PRIMARY KEY (id);


--
-- Name: TipoBeneficio PK40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TipoBeneficio"
    ADD CONSTRAINT "PK40" PRIMARY KEY (id);


--
-- Name: SimulacaoBanco PK43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SimulacaoBanco"
    ADD CONSTRAINT "PK43" PRIMARY KEY (id);


--
-- Name: SituacaoProposta PK44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SituacaoProposta"
    ADD CONSTRAINT "PK44" PRIMARY KEY (id);


--
-- Name: AnaliseProposta PK45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AnaliseProposta"
    ADD CONSTRAINT "PK45" PRIMARY KEY (id);


--
-- Name: SituacaoControleProducao PK46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SituacaoControleProducao"
    ADD CONSTRAINT "PK46" PRIMARY KEY (id);


--
-- Name: Simulacao PK8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Simulacao"
    ADD CONSTRAINT "PK8" PRIMARY KEY (id);


--
-- Name: Ref1186; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref1186" ON public."Digitacao" USING btree ("idCliente");


--
-- Name: Ref12; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref12" ON public."Telefone" USING btree ("IdCliente");


--
-- Name: Ref1223; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref1223" ON public."PreAgendamento" USING btree ("idCliente");


--
-- Name: Ref165; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref165" ON public."Simulacao" USING btree ("idCliente");


--
-- Name: Ref1946; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref1946" ON public."Perfil_Usuario" USING btree ("idUsuario");


--
-- Name: Ref1956; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref1956" ON public."Empresa" USING btree ("idUsuario");


--
-- Name: Ref20205; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref20205" ON public."TransacaoPerfil" USING btree ("idPerfil");


--
-- Name: Ref2051; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref2051" ON public."Perfil_Usuario" USING btree ("idPerfil");


--
-- Name: Ref21203; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref21203" ON public."TransacaoPerfil" USING btree ("idTelaTransacao");


--
-- Name: Ref24188; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref24188" ON public."DocumentoCliente" USING btree ("idDigitacao");


--
-- Name: Ref24194; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref24194" ON public."AnaliseProposta" USING btree ("idDigitacao");


--
-- Name: Ref2896; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref2896" ON public."DocumentoCliente" USING btree (id);


--
-- Name: Ref2982; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref2982" ON public."Cliente" USING btree ("idSitucaoCredito");


--
-- Name: Ref35214; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref35214" ON public."Produto_Banco" USING btree ("idBanco");


--
-- Name: Ref37216; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref37216" ON public."Produto_Banco" USING btree ("IdProduto");


--
-- Name: Ref39207; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref39207" ON public."SimulacaoBanco" USING btree ("idProdutoBanco");


--
-- Name: Ref40118; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref40118" ON public."Cliente" USING btree ("idTipoBeneficiario");


--
-- Name: Ref44218; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref44218" ON public."AnaliseProposta" USING btree ("idSituacaoProposta");


--
-- Name: Ref45201; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref45201" ON public."ControleProducao" USING btree ("IdAnaliseProposta");


--
-- Name: Ref45222; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref45222" ON public."CartelaClienteFinanceira" USING btree ("idAnaliseProposta");


--
-- Name: Ref46199; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref46199" ON public."ControleProducao" USING btree ("idSituacaoControleProducao");


--
-- Name: Ref8182; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref8182" ON public."SimulacaoBanco" USING btree ("idSimulacao");


--
-- Name: Ref888; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ref888" ON public."DocumentoAssinatura" USING btree ("idSimulacao");


--
-- Name: ControleProducao RefAnaliseProposta201; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ControleProducao"
    ADD CONSTRAINT "RefAnaliseProposta201" FOREIGN KEY ("IdAnaliseProposta") REFERENCES public."AnaliseProposta"(id);


--
-- Name: CartelaClienteFinanceira RefAnaliseProposta222; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CartelaClienteFinanceira"
    ADD CONSTRAINT "RefAnaliseProposta222" FOREIGN KEY ("idAnaliseProposta") REFERENCES public."AnaliseProposta"(id);


--
-- Name: Produto_Banco RefBanco214; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Produto_Banco"
    ADD CONSTRAINT "RefBanco214" FOREIGN KEY ("idBanco") REFERENCES public."Banco"(id);


--
-- Name: DocumentoCliente RefCartelaClienteFinanceira96; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentoCliente"
    ADD CONSTRAINT "RefCartelaClienteFinanceira96" FOREIGN KEY (id) REFERENCES public."CartelaClienteFinanceira"(id);


--
-- Name: Digitacao RefCliente186; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Digitacao"
    ADD CONSTRAINT "RefCliente186" FOREIGN KEY ("idCliente") REFERENCES public."Cliente"("Id");


--
-- Name: Telefone RefCliente2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Telefone"
    ADD CONSTRAINT "RefCliente2" FOREIGN KEY ("IdCliente") REFERENCES public."Cliente"("Id");


--
-- Name: PreAgendamento RefCliente223; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAgendamento"
    ADD CONSTRAINT "RefCliente223" FOREIGN KEY ("idCliente") REFERENCES public."Cliente"("Id");


--
-- Name: Simulacao RefCliente65; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Simulacao"
    ADD CONSTRAINT "RefCliente65" FOREIGN KEY ("idCliente") REFERENCES public."Cliente"("Id");


--
-- Name: DocumentoCliente RefDigitacao188; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentoCliente"
    ADD CONSTRAINT "RefDigitacao188" FOREIGN KEY ("idDigitacao") REFERENCES public."Digitacao"(id);


--
-- Name: AnaliseProposta RefDigitacao194; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AnaliseProposta"
    ADD CONSTRAINT "RefDigitacao194" FOREIGN KEY ("idDigitacao") REFERENCES public."Digitacao"(id);


--
-- Name: TransacaoPerfil RefPerfil205; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TransacaoPerfil"
    ADD CONSTRAINT "RefPerfil205" FOREIGN KEY ("idPerfil") REFERENCES public."Perfil"(id);


--
-- Name: Perfil_Usuario RefPerfil51; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Perfil_Usuario"
    ADD CONSTRAINT "RefPerfil51" FOREIGN KEY ("idPerfil") REFERENCES public."Perfil"(id);


--
-- Name: Produto_Banco RefProduto216; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Produto_Banco"
    ADD CONSTRAINT "RefProduto216" FOREIGN KEY ("IdProduto") REFERENCES public."Produto"("Id");


--
-- Name: SimulacaoBanco RefProduto_Banco207; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SimulacaoBanco"
    ADD CONSTRAINT "RefProduto_Banco207" FOREIGN KEY ("idProdutoBanco") REFERENCES public."Produto_Banco"(id);


--
-- Name: SimulacaoBanco RefSimulacao182; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SimulacaoBanco"
    ADD CONSTRAINT "RefSimulacao182" FOREIGN KEY ("idSimulacao") REFERENCES public."Simulacao"(id);


--
-- Name: DocumentoAssinatura RefSimulacao88; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentoAssinatura"
    ADD CONSTRAINT "RefSimulacao88" FOREIGN KEY ("idSimulacao") REFERENCES public."Simulacao"(id);


--
-- Name: ControleProducao RefSituacaoControleProducao199; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ControleProducao"
    ADD CONSTRAINT "RefSituacaoControleProducao199" FOREIGN KEY ("idSituacaoControleProducao") REFERENCES public."SituacaoControleProducao"(id);


--
-- Name: Cliente RefSituacaoCredito82; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cliente"
    ADD CONSTRAINT "RefSituacaoCredito82" FOREIGN KEY ("idSitucaoCredito") REFERENCES public."SituacaoCredito"("idCliente");


--
-- Name: AnaliseProposta RefSituacaoProposta218; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AnaliseProposta"
    ADD CONSTRAINT "RefSituacaoProposta218" FOREIGN KEY ("idSituacaoProposta") REFERENCES public."SituacaoProposta"(id);


--
-- Name: TransacaoPerfil RefTelaTransacao203; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TransacaoPerfil"
    ADD CONSTRAINT "RefTelaTransacao203" FOREIGN KEY ("idTelaTransacao") REFERENCES public."TelaTransacao"(id);


--
-- Name: Cliente RefTipoBeneficio118; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cliente"
    ADD CONSTRAINT "RefTipoBeneficio118" FOREIGN KEY ("idTipoBeneficiario") REFERENCES public."TipoBeneficio"(id);


--
-- Name: Perfil_Usuario RefUsuario46; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Perfil_Usuario"
    ADD CONSTRAINT "RefUsuario46" FOREIGN KEY ("idUsuario") REFERENCES public."Usuario"(id);


--
-- Name: Empresa RefUsuario56; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Empresa"
    ADD CONSTRAINT "RefUsuario56" FOREIGN KEY ("idUsuario") REFERENCES public."Usuario"(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO lucasinformatica;


--
-- PostgreSQL database dump complete
--

